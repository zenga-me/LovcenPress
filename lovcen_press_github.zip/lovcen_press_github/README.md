# Lovćen Press

Kompletan Flask news portal za Lovćen Press.

## Struktura
- `app.py` — Flask aplikacija i SQLite logika
- `templates/` — HTML stranice
- `static/` — CSS i upload direktorijum
- `requirements.txt` — Python zavisnosti
- `Procfile` — start komanda za hosting
- `render.yaml` — opciona Render konfiguracija

## Lokalno pokretanje
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Otvori `http://127.0.0.1:5000`.

## Admin
Demo admin nalog se kreira pri prvom pokretanju:
- korisnik: `admin`
- lozinka: `LovcenPress2026!`

**Obavezno promijeniti lozinku prije javnog rada.**

## GitHub
Ovaj folder je spreman za upload u GitHub repository `lovcen-press`. Ne uploaduju se SQLite baza, uploadovane fotografije, virtualno okruženje ni `.env` fajl.

## Produkcija
Postaviti jak `SECRET_KEY`, promijeniti admin lozinku i redovno praviti backup baze i fotografija. Za hosting sa više instanci preporučuje se PostgreSQL i eksterno skladište za slike.
