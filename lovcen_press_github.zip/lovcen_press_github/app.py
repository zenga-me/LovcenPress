import os, sqlite3, secrets
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort, send_from_directory, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "lovcen_press.db")
UPLOADS = os.path.join(BASE, "static", "uploads")
os.makedirs(UPLOADS, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-change-this-secret-key-" + secrets.token_hex(16))
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
ALLOWED = {"jpg","jpeg","png","webp","gif"}

CATEGORIES = ["Crna Gora","Politika","Društvo","Ekonomija","Region","Svijet","Sport","Kultura","Lifestyle","Hronika","Turizam"]

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS admins(
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS articles(
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, slug TEXT UNIQUE NOT NULL,
      category TEXT NOT NULL, excerpt TEXT, body TEXT NOT NULL, image TEXT,
      author TEXT DEFAULT 'Lovćen Press', published INTEGER DEFAULT 1,
      views INTEGER DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS comments(
      id INTEGER PRIMARY KEY AUTOINCREMENT, article_id INTEGER NOT NULL,
      name TEXT NOT NULL, email TEXT, body TEXT NOT NULL,
      approved INTEGER DEFAULT 0, created_at TEXT NOT NULL,
      FOREIGN KEY(article_id) REFERENCES articles(id) ON DELETE CASCADE
    );
    """)
    admin = c.execute("SELECT id FROM admins LIMIT 1").fetchone()
    if not admin:
        c.execute("INSERT INTO admins(username,password_hash,created_at) VALUES(?,?,?)",
                  ("admin", generate_password_hash("LovcenPress2026!"), now()))
    count = c.execute("SELECT COUNT(*) n FROM articles").fetchone()["n"]
    if count == 0:
        seed = [
            ("Vlada Crne Gore usvojila važne zaključke o ekonomskom razvoju","vlada-crne-gore-ekonomski-razvoj","Ekonomija",
             "Najnovije odluke Vlade i mjere usmjerene na stabilnost i razvoj.",
             "Vlada Crne Gore usvojila je niz zaključaka koji se odnose na ekonomski razvoj, podršku privredi i nove investicije. Detalji odluka biće predstavljeni javnosti nakon sjednice.",None),
            ("U Budvi sve spremno za novu turističku sezonu","budva-spremna-za-turisticku-sezonu","Turizam",
             "Budva dočekuje sezonu sa novim sadržajima i planovima za goste.",
             "Budva ulazi u novu sezonu sa brojnim programima, turističkom ponudom i infrastrukturnim pripremama. Nadležni očekuju dobru posjećenost.",None),
            ("Crna Gora jača regionalnu saradnju","crna-gora-jaca-regionalnu-saradnju","Region",
             "Nove inicijative za bolju saradnju zemalja regiona.",
             "Predstavnici zemalja regiona razgovarali su o povezivanju, ekonomiji, bezbjednosti i zajedničkim projektima.",None),
            ("Počela akcija pošumljavanja na Lovćenu","posumljavanje-na-lovcenu","Društvo",
             "Građani i volonteri učestvuju u novoj ekološkoj akciji.",
             "Akcija pošumljavanja okupila je volontere, planinare i lokalne organizacije. Cilj je obnova šumskog fonda i podizanje svijesti o zaštiti prirode.",None),
            ("Crnogorski sportisti ostvarili odlične rezultate","crnogorski-sportisti-odlicni-rezultati","Sport",
             "Novi uspjesi crnogorskih sportista na međunarodnim takmičenjima.",
             "Crnogorski sportisti ostvarili su zapažene rezultate na međunarodnim takmičenjima i još jednom predstavili zemlju na najbolji način.",None)
        ]
        for title,slug,cat,ex,body,img in seed:
            t=now(); c.execute("""INSERT INTO articles(title,slug,category,excerpt,body,image,author,published,views,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,1,0,?,?)""",(title,slug,cat,ex,body,img,"Lovćen Press",t,t))
    c.commit(); c.close()

def now(): return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def slugify(s):
    table = str.maketrans("čćžšđČĆŽŠĐ","cczs dCCZS D".replace(" ",""))
    s=s.translate(table).lower()
    import re
    return re.sub(r"[^a-z0-9]+","-",s).strip("-")

def admin_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get("admin_id"):
            return redirect(url_for("login", next=request.path))
        return f(*a,**kw)
    return w

@app.context_processor
def inject():
    return {"categories": CATEGORIES, "admin": bool(session.get("admin_id"))}

@app.route("/")
def index():
    c=db()
    featured=c.execute("SELECT * FROM articles WHERE published=1 ORDER BY created_at DESC LIMIT 1").fetchone()
    latest=c.execute("SELECT * FROM articles WHERE published=1 ORDER BY created_at DESC LIMIT 6").fetchall()
    popular=c.execute("SELECT * FROM articles WHERE published=1 ORDER BY views DESC, created_at DESC LIMIT 5").fetchall()
    c.close()
    return render_template("index.html",featured=featured,latest=latest,popular=popular)

@app.route("/kategorija/<category>")
def category(category):
    if category not in CATEGORIES: abort(404)
    c=db(); articles=c.execute("SELECT * FROM articles WHERE published=1 AND category=? ORDER BY created_at DESC",(category,)).fetchall(); c.close()
    return render_template("category.html",articles=articles,category=category)

@app.route("/vijest/<slug>")
def article(slug):
    c=db(); a=c.execute("SELECT * FROM articles WHERE slug=? AND published=1",(slug,)).fetchone()
    if not a: abort(404)
    c.execute("UPDATE articles SET views=views+1 WHERE id=?",(a["id"],))
    comments=c.execute("SELECT * FROM comments WHERE article_id=? AND approved=1 ORDER BY created_at DESC",(a["id"],)).fetchall()
    popular=c.execute("SELECT * FROM articles WHERE published=1 ORDER BY views DESC LIMIT 5").fetchall()
    c.commit(); c.close()
    return render_template("article.html",article=a,comments=comments,popular=popular)

@app.post("/vijest/<slug>/komentar")
def comment(slug):
    c=db(); a=c.execute("SELECT * FROM articles WHERE slug=? AND published=1",(slug,)).fetchone()
    if not a: abort(404)
    name=request.form.get("name","").strip(); email=request.form.get("email","").strip(); body=request.form.get("body","").strip()
    if not name or not body or len(body)>2000:
        flash("Unesite ime i komentar (maksimalno 2000 znakova).","error")
    else:
        c.execute("INSERT INTO comments(article_id,name,email,body,approved,created_at) VALUES(?,?,?,?,0,?)",(a["id"],name,email,body,now()))
        c.commit(); flash("Komentar je poslat na moderaciju.","success")
    c.close(); return redirect(url_for("article",slug=slug)+"#komentari")

@app.route("/pretraga")
def search():
    q=request.args.get("q","").strip(); rows=[]
    if q:
        c=db(); like=f"%{q}%"
        rows=c.execute("""SELECT * FROM articles WHERE published=1 AND
        (title LIKE ? OR excerpt LIKE ? OR body LIKE ? OR category LIKE ?)
        ORDER BY created_at DESC""",(like,like,like,like)).fetchall(); c.close()
    return render_template("search.html",q=q,articles=rows)

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        c=db(); a=c.execute("SELECT * FROM admins WHERE username=?",(request.form.get("username",""),)).fetchone(); c.close()
        if a and check_password_hash(a["password_hash"],request.form.get("password","")):
            session["admin_id"]=a["id"]; session["admin_username"]=a["username"]
            return redirect(request.args.get("next") or url_for("admin"))
        flash("Pogrešno korisničko ime ili lozinka.","error")
    return render_template("login.html")

@app.get("/logout")
def logout():
    session.clear(); return redirect(url_for("index"))

@app.route("/admin")
@admin_required
def admin():
    c=db(); articles=c.execute("SELECT * FROM articles ORDER BY created_at DESC").fetchall()
    pending=c.execute("SELECT COUNT(*) n FROM comments WHERE approved=0").fetchone()["n"]
    stats={"articles":len(articles),"views":c.execute("SELECT COALESCE(SUM(views),0) n FROM articles").fetchone()["n"],"comments":pending}
    c.close(); return render_template("admin.html",articles=articles,stats=stats)

@app.route("/admin/vijest/nova", methods=["GET","POST"])
@admin_required
def new_article():
    if request.method=="POST":
        return save_article(None)
    return render_template("edit_article.html",article=None)

@app.route("/admin/vijest/<int:id>/uredi", methods=["GET","POST"])
@admin_required
def edit_article(id):
    c=db(); a=c.execute("SELECT * FROM articles WHERE id=?",(id,)).fetchone(); c.close()
    if not a: abort(404)
    if request.method=="POST": return save_article(a)
    return render_template("edit_article.html",article=a)

def save_article(existing):
    title=request.form.get("title","").strip(); category=request.form.get("category","Crna Gora")
    excerpt=request.form.get("excerpt","").strip(); body=request.form.get("body","").strip()
    published=1 if request.form.get("published")=="on" else 0
    if not title or not body:
        flash("Naslov i tekst su obavezni.","error")
        return render_template("edit_article.html",article=existing)
    image=existing["image"] if existing else None
    f=request.files.get("image")
    if f and f.filename:
        ext=f.filename.rsplit(".",1)[-1].lower() if "." in f.filename else ""
        if ext not in ALLOWED:
            flash("Dozvoljene su JPG, PNG, WEBP i GIF slike.","error")
            return render_template("edit_article.html",article=existing)
        filename=secrets.token_hex(10)+"."+ext
        f.save(os.path.join(UPLOADS,filename)); image=filename
    slug=slugify(title)
    c=db()
    try:
        if existing:
            c.execute("""UPDATE articles SET title=?,slug=?,category=?,excerpt=?,body=?,image=?,published=?,updated_at=? WHERE id=?""",
                      (title,slug,category,excerpt,body,image,published,now(),existing["id"]))
        else:
            c.execute("""INSERT INTO articles(title,slug,category,excerpt,body,image,author,published,views,created_at,updated_at)
                      VALUES(?,?,?,?,?,?,?, ?,0,?,?)""",(title,slug,category,excerpt,body,image,"Lovćen Press",published,now(),now()))
        c.commit(); flash("Vijest je sačuvana.","success")
    except sqlite3.IntegrityError:
        flash("Slug već postoji. Promijenite naslov.","error"); c.close(); return render_template("edit_article.html",article=existing)
    c.close(); return redirect(url_for("admin"))

@app.post("/admin/vijest/<int:id>/obrisi")
@admin_required
def delete_article(id):
    c=db(); c.execute("DELETE FROM articles WHERE id=?",(id,)); c.commit(); c.close(); flash("Vijest je obrisana.","success"); return redirect(url_for("admin"))

@app.route("/admin/komentari")
@admin_required
def admin_comments():
    c=db(); comments=c.execute("""SELECT comments.*,articles.title,articles.slug FROM comments
        JOIN articles ON articles.id=comments.article_id ORDER BY comments.created_at DESC""").fetchall(); c.close()
    return render_template("comments.html",comments=comments)

@app.post("/admin/komentar/<int:id>/<action>")
@admin_required
def moderate_comment(id,action):
    c=db()
    if action=="approve": c.execute("UPDATE comments SET approved=1 WHERE id=?",(id,))
    elif action=="delete": c.execute("DELETE FROM comments WHERE id=?",(id,))
    c.commit(); c.close(); return redirect(url_for("admin_comments"))

@app.get("/robots.txt")
def robots():
    return "User-agent: *\nAllow: /\nSitemap: "+request.url_root.rstrip("/")+"/sitemap.xml\n",200,{"Content-Type":"text/plain"}

@app.get("/sitemap.xml")
def sitemap():
    c=db(); rows=c.execute("SELECT slug,updated_at FROM articles WHERE published=1").fetchall(); c.close()
    base=request.url_root.rstrip("/")
    xml=['<?xml version="1.0" encoding="UTF-8"?>','<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',f"<url><loc>{base}/</loc></url>"]
    for r in rows: xml.append(f"<url><loc>{base}/vijest/{r['slug']}</loc><lastmod>{r['updated_at'].split(' ')[0]}</lastmod></url>")
    xml.append("</urlset>")
    return "\n".join(xml),200,{"Content-Type":"application/xml"}

@app.errorhandler(404)
def notfound(e): return render_template("404.html"),404

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)),debug=True)
